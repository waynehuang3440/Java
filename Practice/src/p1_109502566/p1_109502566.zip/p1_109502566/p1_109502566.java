package p1_109502566;

public class p1_109502566 {
    public static void main( String [] args ) {
        System.out.println( "Hello World!!!" );
        System.out.println( "I'm 黃君翰 and my student ID is 109502566." );
    }
}